import time

from apitopdf import APItoPDF
from voice import Voice
from datetime import datetime

now = datetime.now()
time_format = now.strftime("%H%M%S")
FILENAME=f"Storybook{time_format}.txt"

apiTotxt=APItoPDF(FILENAME)
title=apiTotxt

voice=Voice(FILENAME,title)

