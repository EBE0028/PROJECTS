


import random
import time

import requests
from fpdf import FPDF
URL='https://api.npoint.io/329e8ebd6b67e27ee01c'
lst= []
class APItoPDF:
    def __init__(self,Filename):
        self.responce=requests.get(URL)
        data=self.responce.json()[0]
        title_text=data['title']
        self.story_title=title_text
        context_text=data['context']
        fileName=Filename
        print(fileName)
        self.list_text(title_text, context_text,fileName)






    def list_text(self,title,body,fileName):
        print(fileName)
        text_file = open(f"file/{fileName}", "x")
        text_file.close()
        text_file = open(f"file/{fileName}", "w")
        # write string to file
        text_file.write(title)
        text_file.write('\n')
        text_file.write(body)
        text_file.close()
        return str(title)

    def __str__(self):
        return self.story_title










