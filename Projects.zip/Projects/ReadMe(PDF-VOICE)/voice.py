import shutil

from gtts import gTTS
import os
from datetime import datetime




class Voice:

    def __init__(self,Filename,title):
        language = 'en'
        filepath=f"file/{Filename}"
        my_file = open(filepath, "r")
        content = my_file.read()
        voice= gTTS(text=content, lang=language, slow=False)
        now = datetime.now()
        time_format = now.strftime("%H%M%S")
        voice.save(f"voice/{title}.mp3")
        os.system(f"mpg321 {title}.mp3")
