MORSE_CODE_DICT = {'A': '.-', 'B': '-...',
                   'C': '-.-.', 'D': '-..', 'E': '.',
                   'F': '..-.', 'G': '--.', 'H': '....',
                   'I': '..', 'J': '.---', 'K': '-.-',
                   'L': '.-..', 'M': '--', 'N': '-.',
                   'O': '---', 'P': '.--.', 'Q': '--.-',
                   'R': '.-.', 'S': '...', 'T': '-',
                   'U': '..-', 'V': '...-', 'W': '.--',
                   'X': '-..-', 'Y': '-.--', 'Z': '--..',
                   '1': '.----', '2': '..---', '3': '...--',
                   '4': '....-', '5': '.....', '6': '-....',
                   '7': '--...', '8': '---..', '9': '----.',
                   '0': '-----', ', ': '--..--', '.': '.-.-.-',
                   '?': '..--..', '/': '-..-.', '-': '-....-',
                   '(': '-.--.', ')': '-.--.-',
                   ' ': '..'
                   }
encrpyted = []


def encrypt(arr):
    for item in arr:
        varl = item.upper()
        encrpyted.append(MORSE_CODE_DICT[varl])
        print(MORSE_CODE_DICT[varl])


def decrypt(message):
    key_list = list(MORSE_CODE_DICT.keys())
    val_list = list(MORSE_CODE_DICT.values())
    for item in message:
        position = val_list.index(item)
        print(key_list[position], end="")







print("Welcome to MORSE-CODE")

arr = input("Enter the word")
item = encrypt(arr)

Decrypt=bool(input("Do you need to decrypt"))
if Decrypt==True:
    decrypt(encrpyted)




