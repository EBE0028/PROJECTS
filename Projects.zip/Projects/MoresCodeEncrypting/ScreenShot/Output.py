Welcome to MORSE-CODE
Enter the word EBE IS PLAYING WITH GEFFANIAH
..
.
-...
.
..
..
...
..
.--.
.-..
.-
-.--
..
-.
--.
..
.--
..
-
....
..
--.
.
..-.
..-.
.-
-.
..
.-
....
Do you need to decrypt Y
IEBEIISIPLAYINGIWITHIGEFFANIAH