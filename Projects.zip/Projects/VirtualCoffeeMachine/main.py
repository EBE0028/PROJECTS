import AllFunctions
import Dict

flag = 0
while flag != 1:
    coffee_name = input("What would you like? (espresso/latte/cappuccino): ")
    if coffee_name == 'report':
        AllFunctions.Check_report()

    elif coffee_name == 'espresso' or coffee_name == 'latte' or coffee_name == 'cappuccino':

        Res = AllFunctions.Check_avail(coffee_name)

        cost = Dict.MENU[coffee_name]["cost"]

        returnBack = 0

        if Res == 1:
            print(f"Hurray we have started making you coffee {coffee_name} meanwhile please pay your bill of {cost}")
            quarter = int(input("Please enter the number of Quarter you have: "))
            dime = int(input("Please enter the number of dime you have: "))
            nickle = int(input("Please enter the number of nickle you have: "))
            pennie = int(input("Please enter the number of pennie you have: "))
            print(f"Entered amount = {AllFunctions.Process_coins(quarter, dime, nickle, pennie)}")
            paidAmount = round(AllFunctions.Process_coins(quarter, dime, nickle, pennie), 1)
            if paidAmount == cost:
                AllFunctions.Coffee_Making(coffee_name)
                print(f"You coffee {coffee_name} is ready , enjoy the day")
            elif paidAmount > cost:
                returnBack = round((paidAmount - cost), 1)
                print(f"Please get back your remaining amount {returnBack}")
                AllFunctions.Coffee_Making(coffee_name)
                print(f"You coffee {coffee_name} is ready , enjoy the day")
            else:
                returnBack = round((cost - paidAmount), 1)
                print("OOPS insufficient amount entered please retry from first ")
                flag = 1
                break
        else:
            print("OOPS we are empty at this moment please try ain later")
            flag = 1
            break


    else:
        print("Please enter the valid option")
        break
