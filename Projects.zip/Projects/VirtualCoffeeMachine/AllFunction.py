import Dict


def Machine_off_state():
    print("Machine is switched off ")
    print("Please restart the program ")


def Process_coins(quarter, dime, nickle, pennie):
    quarters = 0.25
    dimes = 0.10
    nickles = 0.05
    pennies = 0.01
    return quarters * quarter + dimes * dime + nickles * nickle + pennies * pennie


def Coffee_Making(coffee_name):
    waterContent = Dict.MENU[coffee_name]["ingredients"]["water"]
    CoffeeContent = Dict.MENU[coffee_name]["ingredients"]["coffee"]
    MilkContent = Dict.MENU[coffee_name]["ingredients"]["coffee"]
    WaterAvail = Dict.resources["water"]
    MilkAvail = Dict.resources["milk"]
    CoffeeAvail = Dict.resources["coffee"]
    updatedWater = 0
    updatedMilk = 0
    updatedCoffee = 0
    updatedWater = WaterAvail - waterContent
    updatedCoffee = CoffeeAvail - CoffeeContent
    updatedMilk = MilkAvail - MilkContent
    Dict.resources.update({'milk': updatedMilk})
    Dict.resources.update({'coffee': updatedCoffee})
    Dict.resources.update({'water': updatedWater})


def Check_avail(coffee_name):
    WaterAvail = Dict.resources["water"]
    MilkAvail = Dict.resources["milk"]
    CoffeeAvail = Dict.resources["coffee"]
    ReqWater = Dict.MENU[coffee_name]["ingredients"]["water"]
    ReqMilk = Dict.MENU[coffee_name]["ingredients"]["milk"]
    ReqCoffee = Dict.MENU[coffee_name]["ingredients"]["coffee"]
    if (ReqCoffee < CoffeeAvail) and (ReqMilk < MilkAvail) and (ReqWater < WaterAvail):
        return 1
    else:
        return 0


def Check_report():
    print(Dict.resources)
