from turtle import  Turtle


class Score(Turtle):
    def __init__(self):
        super().__init__()
        self.lives = 3
        self.score = 0
        self.color("white")
        self.hideturtle()
        self.penup()
        self.update_score()

    def update_score(self):
        self.clear()
        self.goto(-350, 270)
        self.write(f"Lives :- {self.lives}", align="center", font = ("Arial", 15, "normal"))
        self.goto(330, 270)
        self.write(f"Score :- {self.score}", align="center", font = ("Arial", 15, "normal"))

    def game_over(self):
        self.clear()
        self.goto(0, 0)
        self.write("Game Over", align="center", font=("Arial", 15, "normal"))
