from turtle import Screen
from paddle import Paddle
from tiles import Tiles
from ball import Ball
from score_board import Score
import time


screen = Screen()
screen.setup(height=600, width=800)
screen.bgcolor("black")
screen.tracer(0)

player = Paddle(0, -280, "white")
tiles = Tiles()
ball = Ball()
score = Score()

game_is_on = True
ball_speed = 0.05

screen.listen()
screen.onkey(player.move_left, 'Left')
screen.onkey(player.move_right, 'Right')
while game_is_on:
    screen.update()
    time.sleep(ball_speed)
    ball.move_ball()

    if ball.xcor() > 380 or ball.xcor() < -380:
        ball.bounce_x()

    if ball.ycor() > 280 or ball.distance(player) < 50 :
        ball.bounce_y()

    if ball.ycor() < -280:
        ball.reset_ball()
        score.lives -= 1

    for item in tiles.all_tile:
        if item["tile"].distance(ball) < 50:
            ball.bounce_y()
            item["tile"].reset()
            score.score += 10

    score.update_score()
    if score.lives == 0:
        game_is_on = False
        score.game_over()


screen.exitonclick()