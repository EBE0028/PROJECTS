from paddle import Paddle
import random

colors = ["yellow", "gold", "orange", "red", "maroon", "violet", "magenta", "purple", "navy",
          "blue", "skyblue", "cyan", "turquoise", "lightgreen", "green", "darkgreen", "chocolate",
          "brown", "gray"]
start_x_cor = -350
start_y_cor = 250


class Tiles():
    def __init__(self):
        self.all_tile = []
        for num in range(11):
            global start_x_cor, start_y_cor
            if start_x_cor == 420:
                start_x_cor = -350
                start_y_cor -= 30
            x_pos = start_x_cor
            y_pos = start_y_cor
            color = random.choice(colors)
            paddle_details = {
                "index" : num,
                "x_pos" : x_pos,
                "y_pos" : y_pos,
                "color" : color,
                "tile" : Paddle(x_pos, y_pos, color)
            }
            self.all_tile.append(paddle_details)
            start_x_cor += 70