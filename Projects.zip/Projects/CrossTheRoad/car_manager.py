COLORS = ["red", "orange", "yellow", "green", "blue", "purple"]
STARTING_MOVE_DISTANCE = 5
MOVE_INCREMENT = 10
from turtle import Turtle
import random

class CarManager:
    def __init__(self):
        super().__init__()
        self.All_car=[]
        self.movement=MOVE_INCREMENT



    def create_new_car(self):
        car_density=random.randint(1,4)
        if car_density == 1:
            new_car=Turtle("square")
            new_car.penup()
            new_car.shapesize(stretch_wid=1, stretch_len=2)
            new_car.color(random.choice(COLORS))
            random_y=random.randint(-250,250)
            new_car.goto(300, random_y)
            new_car.speed(self.movement)
            self.All_car.append(new_car)

    def move_cars(self):
        for car in self.All_car:
            car.backward(self.movement)









