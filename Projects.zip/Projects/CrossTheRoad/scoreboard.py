FONT = ("Courier", 24, "normal")
from turtle import Turtle


class Scoreboard(Turtle):
    def __init__(self):
        super().__init__()
        self.penup()
        self.hideturtle()
        self.score = 0
        self.goto(-200, 240)
        self.write(f"Level : {self.score} ", align="center", font=FONT)

    def inc_score(self):
        self.clear()
        self.score += 1
        self.goto(-200, 240)
        self.write(f"Level : {self.score} ", align="center", font=FONT)

    def gameover(self):
        self.goto(0,0)
        self.write("GAME OVER", align="center", font=FONT)
