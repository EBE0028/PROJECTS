import random
import time
from turtle import Screen
from player import Player
from car_manager import CarManager
from scoreboard import Scoreboard

screen = Screen()
screen.setup(width=600, height=600)
screen.tracer(0)
player = Player()
obs = CarManager()
score = Scoreboard()

screen.listen()
screen.onkey(player.move_up, "Up")
screen.onkey(player.move_down, "Down")

game_is_on = True

while game_is_on:
    time.sleep(0.1)
    screen.update()
    obs.create_new_car()
    obs.move_cars()

    for item in obs.All_car:
        if item.distance(player) < 15:
            game_is_on = False
            score.gameover()

    if player.ycor() > 270:
        score.inc_score()
        obs.movement += 10
        player.reset_game()


screen.exitonclick()
