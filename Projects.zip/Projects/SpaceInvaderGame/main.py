import turtle
from turtle import Turtle, Screen, distance
import time
import keyboard
import overlap as overlap
from turtle import *
from aliens import CarManager
from Shooter import Shooter
from scoreboard import Scoreboard
from time_display import Time_display

screen=Screen()
screen.bgcolor("black")
screen.title("CATCH THE WEIRDO")
score=Scoreboard()

screen.setup(width=500, height=500)
shooter=Shooter()
time_dis=Time_display()
count=0
bullet=Turtle()
bullet.left(90)
alien=CarManager()
screen.listen()
screen.onkey(shooter.move_right, "Right")
screen.onkey(shooter.move_left, "Left")
for i in range(0,1000):
    time.sleep(0.1)
    # screen.update()
    alien.create_new_aliens()
    alien.move_alien()
    if keyboard.is_pressed('W'):
        bullet.penup()
        init_pos=shooter.pos()
        x_pos=init_pos[0]
        bullet.color('red')
        bullet.goto(init_pos)
        bullet.shape("classic")
        bullet.shapesize(stretch_wid=2, stretch_len=2)
        bullet.speed(3)
        bullet.goto(x_pos,300)
        bullet.goto(init_pos)
        for item in alien.All_aliens:
            if item.distance(bullet) <= 300:
                score.inc_score()
    time_dis.inc_time()
    if time_dis.count > 200:
        screen.bye()





screen.exitonclick()
