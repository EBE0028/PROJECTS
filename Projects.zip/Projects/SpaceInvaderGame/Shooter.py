from turtle import Turtle


class Shooter(Turtle):
    def __init__(self):
        super().__init__()
        self.penup()
        self.color("white")
        self.left(90)
        self.shape("arrow")
        self.shapesize(stretch_wid=2, stretch_len=3)
        self.goto(0, -200)
        new_x=0



    def move_right(self):

        new_x = self.xcor() + 20
        self.goto(new_x, self.ycor())
        if new_x == 200:
            self.goto(0, -200)



    def move_left(self):

        new_x = self.xcor() - 20
        self.goto(new_x, self.ycor())
        if new_x == -200:
            self.goto(0, -200)










