FONT = ("Courier", 18, "normal")
from turtle import Turtle,Screen


class Scoreboard(Turtle):
    def __init__(self):
        super().__init__()
        self.penup()
        self.hideturtle()
        self.color('white')
        self.score = 0
        self.goto(-170, 210)
        self.write(f"Score : {self.score} ", align="center", font=FONT)

    def inc_score(self):
        self.clear()
        self.score += 1
        self.goto(-170, 210)
        self.write(f"Score : {self.score} ", align="center", font=FONT)


