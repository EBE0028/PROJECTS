FONT = ("Courier", 18, "normal")
from turtle import Turtle,Screen


class Time_display(Turtle):
    def __init__(self):
        super().__init__()
        self.penup()
        self.hideturtle()
        self.color('white')
        self.count = 0
        self.goto(140, 210)
        self.write(f"Life Time : {self.count} ", align="center", font=FONT)

    def inc_time(self):
        self.clear()
        self.count += 1
        self.goto(140, 210)
        self.write(f"Life Time : {self.count} ", align="center", font=FONT)


