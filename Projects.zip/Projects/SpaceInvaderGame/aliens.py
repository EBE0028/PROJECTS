
COLORS = ["red", "orange", "yellow", "green", "blue", "purple"]
SHAPE = ["triangle", "square", "circle", "turtle", "arrow", "classic"]
STARTING_MOVE_DISTANCE = 5
MOVE_INCREMENT = 10
from turtle import Turtle
import random

class CarManager:
    def __init__(self):
        super().__init__()
        self.All_aliens=[]
        self.movement=MOVE_INCREMENT



    def create_new_aliens(self):
        alien_density=random.randint(1,8)
        if alien_density == 1:
            shape=random.choice(SHAPE)
            new_alien=Turtle(shape)
            new_alien.penup()
            new_alien.shapesize(stretch_wid=2, stretch_len=2)
            new_alien.color(random.choice(COLORS))
            random_y=random.randint(0,170)
            new_alien.goto(300, random_y)
            new_alien.speed(self.movement)
            self.All_aliens.append(new_alien)

    def move_alien(self):
        for alien in self.All_aliens:
            alien.backward(self.movement)









