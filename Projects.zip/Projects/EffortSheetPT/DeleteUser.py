from datetime import datetime
from fileinput import input
from http import client
from tkinter import *
from pymongo import MongoClient

root = Tk()
root.geometry("415x315")
root.title("                                DELETE USER    ")
client=MongoClient('localhost',27017)

def DeleteAct():
    database = client['EFT']
    collection = database['EFT']
    inputid = input_box_id.get("1.0", 'end-1c')
    if len(inputid) != 0:
        if collection.find_one({"Empid": int(inputid)}):
            collection.delete_one({"Empid": int(inputid)})
            result.config(text="User deleted successfully")
        else:
            result.config(text="User Does not exist ")
    else:
        result.config(text="Please enter valid input")


def HomeAct():
    root.destroy()
    import main


Title = Label(root,text='DELETE AN USER FROM OUR TEAM\n Please enter the "Employee id"', height=3,
                  width=50,
                  bg="light blue")
Title.config(font =("Helvetica", 8,'bold'))
Title.grid(row=1, column=1, padx=30,pady=10)


input_box_id = Text(root, height=2,
                 width=10,
                 bg="light yellow")

input_box_id.grid(row=2, column=1, pady=5)


Add = Button(root, height=2,
               width=28,
               text="Enter",
                  command=lambda: DeleteAct())
Add.grid(row=3, column=1, pady=5)

result = Label(root, height=5,
                              width=28,
                              bg="light yellow")
result.grid(row=4, column=1, pady=5)
exitButton=Button(root, height=2,
               width=50,
               text="Home",
               command=lambda: HomeAct())
exitButton.grid(row=5, column=1, pady=5)

mainloop()