from datetime import datetime
from fileinput import input
from http import client
from tkinter import *
from pymongo import MongoClient

root = Tk()
root.geometry("415x500")
# root.title("                                CREATE USER    ")
client=MongoClient('localhost',27017)

def AddAct():
    database = client['EFT']
    collection = database['EFT']
    inputid = input_box_id.get("1.0", 'end-1c')
    inputname = input_box_name.get("1.0", 'end-1c')
    inputwork = input_box_work.get("1.0", 'end-1c')
    if len(inputid)!=0 and len(inputname)!=0 and len(inputwork)!=0:
        if collection.find_one({"Empid": int(inputid)}):
            result.config(text="User already exists ")
        else:
            today_Date = datetime.today().strftime('%d-%m-%Y')
            collection.insert_one(
                {"Empid": int(inputid), "Date": [today_Date], "Work": [inputwork], "name":inputname})
            result.config(text="Successfully entered the new user")

    else:
        result.config(text="Please enter valid input")


def HomeAct():
    root.destroy()
    import main


Title = Label(root,text='ADD AN USER TO OUR TEAM\n Please enter the "Employee id" , "Name" , "Work"', height=3,
                  width=50,
                  bg="light blue")
Title.config(font =("Helvetica", 8,'bold'))
Title.grid(row=1, column=1, padx=30,pady=10)


input_box_id = Text(root, height=2,
                 width=10,
                 bg="light yellow")

input_box_id.grid(row=2, column=1, pady=5)

input_box_name = Text(root, height=2,
                 width=10,
                 bg="light yellow")

input_box_name.grid(row=3, column=1, pady=5)

input_box_work = Text(root, height=5,
                 width=30,
                 bg="light yellow")

input_box_work.grid(row=4, column=1, pady=5)

Add = Button(root, height=2,
               width=28,
               text="Enter",
                  command=lambda: AddAct())
Add.grid(row=5, column=1, pady=5)

result = Label(root, height=5,
                              width=28,
                              bg="light yellow")
result.grid(row=6, column=1, pady=5)
exitButton=Button(root, height=2,
               width=50,
               text="Home",
               command=lambda: HomeAct())
exitButton.grid(row=7, column=1, pady=5)

mainloop()