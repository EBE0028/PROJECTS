from datetime import datetime
from fileinput import input
from http import client
from tkinter import *
from pymongo import MongoClient

root = Tk()
root.geometry("415x500")
root.title("                                ENTER DAILY ACTIVITY    ")
client=MongoClient('localhost',27017)

def Daily_Act_enter():
    database = client['EFT']
    collection = database['EFT']
    inputVal=input_box_name.get("1.0",'end-1c')
    inputWork=input_box_work.get("1.0",'end-1c')
    flag=0
    if inputVal.isdigit():
        if collection.find_one({"Empid":int(inputVal)}) :
            today_Date=datetime.today().strftime('%d-%m-%Y')
            for i in collection.aggregate([{"$match": {"Empid": int(inputVal)}},
                                           {"$project": {"matchedIndex": {"$indexOfArray": ["$Date", today_Date]}}}]):
                print((i.values()))
                count = 0
                for i in i.values():
                    if count == 1:
                        print(i)
                        flag=i
                    count += 1
            if flag==0 or flag==-1:
                collection.update_one({"Empid": int(inputVal)}, {"$push": {"Date": today_Date}})
                collection.update_one({"Empid": int(inputVal)}, {"$push": {"Work": inputWork}})
                result.config(text="Your record is captured !Thank you!")
            else:
                result.config(text="You have entered already ")
                print("not exeted")
        else:
            result.config(text="not found")
    else:
        result.config(text="Not a valid Employee ID")
    root.destroy()
    import main

def HomeAct():
    root.destroy()
    import main





Title = Label(root,text="WHAT IS YOU ACTIVITY TODAY\n Please enter your Employee id first and your work details", height=3,
                  width=50,
                  bg="light blue")
Title.config(font =("Helvetica", 8,'bold'))
Title.grid(row=1, column=1, padx=30,pady=10)


input_box_name = Text(root, height=2,
                 width=10,
                 bg="light yellow")

input_box_name.grid(row=2, column=1, pady=5)

input_box_work = Text(root, height=3,
                 width=30,
                 bg="light yellow")
input_box_work.grid(row=3, column=1, pady=5)

DailyAct = Button(root, height=2,
               width=28,
               text="Enter",
               command=lambda: Daily_Act_enter())
DailyAct.grid(row=4, column=1, pady=5)

result = Label(root, height=3,
                              width=30,
                              bg="light yellow")
result.grid(row=5, column=1, pady=5)

exitButton=Button(root, height=2,
               width=50,
               text="Home",
               command=lambda: HomeAct())
exitButton.grid(row=6, column=1, pady=5)
mainloop()