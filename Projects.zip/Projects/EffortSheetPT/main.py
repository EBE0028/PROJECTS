from tkinter import *


root = Tk()
root.geometry("415x385")
root.title("                                EFFORT-TRACKER    ")

def Daily_Act():
    root.destroy()
    import DailyAct
def Find_Act():
    root.destroy()
    import FindAct

def Find_all_Act():
    root.destroy()
    import FindAll

def CreateUser():
    root.destroy()
    import CreateUser

def DeleteUser():
    root.destroy()
    import DeleteUser

Title = Label(root,text="Lets Track our daily efforts ", height=3,
                  width=30,
                  bg="light blue")
Title.config(font =("Helvetica", 10,'bold'))
Title.grid(row=1, column=1, padx=80,pady=10)


DailyAct = Button(root, height=2,
               width=28,
               text="WHAT IS YOUR ACTIVITY TODAY",
               command=lambda: Daily_Act())
DailyAct.grid(row=3, column=1, pady=5)
FindAct = Button(root, height=2,
               width=28,
               text="FIND ACTIVITY",
               command=lambda: Find_Act())
FindAct.grid(row=4, column=1, pady=5)
FindAllAct = Button(root, height=2,
               width=28,
               text="FIND ALL ACTIVITY",
               command=lambda: Find_all_Act())
FindAllAct.grid(row=4, column=1, pady=5)

CreateUserAct = Button(root, height=2,
               width=28,
               text="ADD USER ",
               command=lambda: CreateUser())
CreateUserAct.grid(row=5, column=1, pady=5)

DeleteUserAct = Button(root, height=2,
               width=28,
               text="DELETE USER ",
               command=lambda: DeleteUser())
DeleteUserAct.grid(row=6, column=1, pady=5)

Exit = Button(root, height=2,
               width=38,
               text="EXIT",
               command=lambda: root.destroy())
Exit.grid(row=7, column=1, pady=5)



mainloop()