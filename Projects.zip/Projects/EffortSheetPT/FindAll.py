from datetime import datetime
from fileinput import input
from http import client
from tkinter import *
from pymongo import MongoClient

root = Tk()
root.geometry("415x500")
root.title("                                FIND ALL ACTIVITY    ")
client=MongoClient('localhost',27017)

def FindAllAct():
    database = client['EFT']
    collection = database['EFT']
    inputVal = input_box_date.get("1.0", 'end-1c')
    if len(inputVal)!=0:
        lst=[]
        NAME = []
        WORK = []
        for item in collection.find({"Date": {"$in": [inputVal]}}):
            work = item["Work"]
            name = item["name"]
            NAME.append(name)
            WORK.append(work)
        limit = len(WORK)
        if limit !=0:
            FINALRESULT_NW = {NAME[i]: WORK[i] for i in range(0, len(WORK))}
            for (key, value) in FINALRESULT_NW.items():
                text=f"{key}  :  {value}"
                lst.append(text)
            listToStr = ' '.join([f"{str(elem)}\n" for elem in lst])
            result.config(text=str(listToStr))
        else:
            result.config(text="There is no entry Please check you Date format")
    else:
        result.config(text="PLease check your DATE FORMAT DD-MM-YYYY")


def HomeAct():
    root.destroy()
    import main


Title = Label(root,text="LET'S FIND EVERYONE'S ACTIVITY\n Please enter the Date in DD-MM-YYYY ", height=3,
                  width=50,
                  bg="light blue")
Title.config(font =("Helvetica", 8,'bold'))
Title.grid(row=1, column=1, padx=30,pady=10)


input_box_date = Text(root, height=2,
                 width=10,
                 bg="light yellow")

input_box_date.grid(row=2, column=1, pady=5)


DailyAct = Button(root, height=2,
               width=28,
               text="Enter",
                  command=lambda: FindAllAct())
DailyAct.grid(row=3, column=1, pady=5)

result = Label(root, height=18,
                              width=50,
                              bg="light yellow")
result.grid(row=4, column=1, pady=5)
exitButton=Button(root, height=2,
               width=50,
               text="Home",
               command=lambda: HomeAct())
exitButton.grid(row=5, column=1, pady=5)

mainloop()